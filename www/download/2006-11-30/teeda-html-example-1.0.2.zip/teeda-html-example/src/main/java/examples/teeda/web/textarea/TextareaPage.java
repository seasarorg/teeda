package examples.teeda.web.textarea;

public class TextareaPage {

	private String aaa;

	public String getAaa() {
		return aaa;
	}

	public void setAaa(String aaa) {
		this.aaa = aaa;
	}

}
