package examples.teeda.web.label;

public class LabelPage {

	private String name = "Foo";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
