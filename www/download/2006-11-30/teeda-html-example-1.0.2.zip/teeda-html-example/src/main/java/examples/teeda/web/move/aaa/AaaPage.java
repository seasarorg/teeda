/**
 *
 */
package examples.teeda.web.move.aaa;

/**
 * @author shot
 */
public class AaaPage {

}
