/**
 *
 */
package examples.teeda.web.condition;

/**
 * @author shot
 */
public class ConditionPage {

	private Boolean aaa = Boolean.TRUE;

	private String bbb = "BBB";

	private String ccc = "CCC";

	public Boolean isAaa() {
		return aaa;
	}

	public String getBbb() {
		return bbb;
	}

	public String getCcc() {
		return ccc;
	}

	public void setAaa(Boolean aaa) {
		this.aaa = aaa;
	}

	public void setBbb(String bbb) {
		this.bbb = bbb;
	}

	public void setCcc(String ccc) {
		this.ccc = ccc;
	}

}
