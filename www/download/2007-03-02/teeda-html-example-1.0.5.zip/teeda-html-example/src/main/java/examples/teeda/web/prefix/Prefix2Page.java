package examples.teeda.web.prefix;

public class Prefix2Page {

	public String initialize() {
		return null;
	}

	public String prerender() {
		return null;
	}

	public String doAction() {
		return "prefix3";
	}
}
