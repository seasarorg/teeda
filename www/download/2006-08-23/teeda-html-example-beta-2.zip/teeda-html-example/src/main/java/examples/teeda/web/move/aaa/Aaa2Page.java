/**
 *
 */
package examples.teeda.web.move.aaa;

/**
 * @author shot
 */
public class Aaa2Page {

}
