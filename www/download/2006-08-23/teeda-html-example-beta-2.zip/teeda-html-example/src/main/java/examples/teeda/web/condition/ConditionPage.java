/**
 *
 */
package examples.teeda.web.condition;

/**
 * @author shot
 */
public class ConditionPage {

	private boolean aaa = true;

	private String bbb = "BBB";

	private String ccc = "CCC";

	public boolean isAaa() {
		return aaa;
	}

	public String getBbb() {
		return bbb;
	}

	public String getCcc() {
		return ccc;
	}

	public void setAaa(boolean aaa) {
		this.aaa = aaa;
	}

	public void setBbb(String bbb) {
		this.bbb = bbb;
	}

	public void setCcc(String ccc) {
		this.ccc = ccc;
	}

}
