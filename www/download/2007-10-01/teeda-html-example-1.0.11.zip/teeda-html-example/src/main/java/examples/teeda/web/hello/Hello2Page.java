package examples.teeda.web.hello;

public class Hello2Page {

	public String hoge = "Teeda";

	public Class initialize() {
		return null;
	}

	public Class prerender() {
		return null;
	}

	public String getLayout() {
		return null;
	}
}
