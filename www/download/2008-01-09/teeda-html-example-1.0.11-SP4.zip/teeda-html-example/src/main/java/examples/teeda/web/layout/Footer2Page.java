package examples.teeda.web.layout;

public class Footer2Page {

	public Class initialize() {
		System.out.println("footer init");
		return null;
	}

	public Class prerender() {
		System.out.println("footer prerender");
		return null;
	}

}
