package examples.teeda.web.ajax;

public class LitboxPage {
	
	private String message;

	public String initialize() {
		return null;
	}

	public String prerender() {
		return null;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String sendMessage) {
		this.message = sendMessage;
	}


}
