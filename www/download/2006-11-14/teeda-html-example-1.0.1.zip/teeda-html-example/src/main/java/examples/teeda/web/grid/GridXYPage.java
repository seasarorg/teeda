package examples.teeda.web.grid;

public class GridXYPage extends GridPage {

}
