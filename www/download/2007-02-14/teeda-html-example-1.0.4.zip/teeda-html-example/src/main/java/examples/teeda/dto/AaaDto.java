package examples.teeda.dto;

public class AaaDto {

	private String bbb = "Teeda";

	public AaaDto() {
	}

	public String getBbb() {
		return bbb;
	}

	public void setBbb(String bbb) {
		this.bbb = bbb;
	}

}
