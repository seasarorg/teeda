/*
 * Copyright 2004-2006 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package javax.faces.convert;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

import javax.faces.component.StateHolder;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.internal.AssertionUtil;
import javax.faces.internal.ConvertUtils;

import org.seasar.framework.util.DateConversionUtil;

/**
 * @author higa
 * 
 */
public class DateTimeConverter implements Converter, StateHolder {

    public static final String CONVERTER_ID = "javax.faces.DateTime";

    protected static final String STYLE_DEFAULT = "default";

    protected static final String STYLE_MEDIUM = "medium";

    protected static final String STYLE_SHORT = "short";

    protected static final String STYLE_LONG = "long";

    protected static final String STYLE_FULL = "full";

    protected static final String TYPE_DATE = "date";

    protected static final String TYPE_TIME = "time";

    protected static final String TYPE_BOTH = "both";

    private String dateStyle_ = STYLE_DEFAULT;

    private boolean transientValue_ = false;

    private Locale locale_ = null;

    private String pattern_ = null;

    private String timeStyle_ = STYLE_DEFAULT;

    private static final TimeZone DEFAULT_TIME_ZONE = TimeZone.getDefault();

    private TimeZone timeZone_ = DEFAULT_TIME_ZONE;

    private String type_ = TYPE_DATE;

    public DateTimeConverter() {
    }

    public Object getAsObject(FacesContext context, UIComponent component,
            String value) throws ConverterException {
        AssertionUtil.assertNotNull("FacesContext", context);
        AssertionUtil.assertNotNull("UIComponent", component);
        if (value == null) {
            return null;
        }
        value = value.trim();
        if (value.length() < 1) {
            return null;
        }
        Locale locale = getLocale();
        DateFormat format = getDateFormat(value, locale);
        if (format == null) {
            format = DateConversionUtil.getDateFormat(value, locale);
        }
        format.setLenient(false);
        TimeZone timeZone = getTimeZone();
        if (timeZone != null) {
            format.setTimeZone(timeZone);
        }
        try {
            return format.parse(value);
        } catch (ParseException e) {
            Object[] args = ConvertUtils.createExceptionMessageArgs(component,
                    value);
            throw ConvertUtils.wrappedByConverterException(this, context, args,
                    e);
        }
    }

    public String getAsString(FacesContext context, UIComponent component,
            Object value) throws ConverterException {
        AssertionUtil.assertNotNull("FacesContext", context);
        AssertionUtil.assertNotNull("UIComponent", component);
        if (value == null) {
            return "";
        }
        if (value instanceof String) {
            return (String) value;
        }
        DateFormat formatter = getDateFormat(getLocale());
        TimeZone timeZone = getTimeZone();
        if (timeZone != null) {
            formatter.setTimeZone(timeZone);
        }
        try {
            return formatter.format(value);
        } catch (Exception e) {
            throw ConvertUtils.wrappedByConverterException(e);
        }
    }

    public boolean isTransient() {
        return transientValue_;
    }

    public void setTransient(boolean transientValue) {
        transientValue_ = transientValue;
    }

    public Object saveState(FacesContext context) {
        Object[] values = new Object[6];
        values[0] = dateStyle_;
        values[1] = locale_;
        values[2] = pattern_;
        values[3] = timeStyle_;
        values[4] = timeZone_;
        values[5] = type_;
        return values;
    }

    public void restoreState(FacesContext context, Object state) {
        Object[] values = (Object[]) state;
        dateStyle_ = (String) values[0];
        locale_ = (Locale) values[1];
        pattern_ = (String) values[2];
        timeStyle_ = (String) values[3];
        timeZone_ = (TimeZone) values[4];
        type_ = (String) values[5];
    }

    public String getDateStyle() {
        return dateStyle_;
    }

    public void setDateStyle(String dateStyle) {
        dateStyle_ = dateStyle;
    }

    public Locale getLocale() {
        if (locale_ == null) {
            locale_ = getLocale(FacesContext.getCurrentInstance());
        }
        return locale_;
    }

    public void setLocale(Locale locale) {
        locale_ = locale;
    }

    public String getPattern() {
        return pattern_;
    }

    public void setPattern(String pattern) {
        pattern_ = pattern;
    }

    public String getTimeStyle() {
        return timeStyle_;
    }

    public void setTimeStyle(String timeStyle) {
        timeStyle_ = timeStyle;
    }

    public TimeZone getTimeZone() {
        return timeZone_;
    }

    public void setTimeZone(TimeZone timeZone) {
        timeZone_ = timeZone;
    }

    public String getType() {
        return type_;
    }

    public void setType(String type) {
        type_ = type;
    }

    private Locale getLocale(FacesContext context) {
        return context.getViewRoot().getLocale();
    }

    protected DateFormat getDateFormat(Locale locale) {
        String pattern = getPattern();
        if (pattern != null) {
            return new SimpleDateFormat(pattern, locale);
        }
        if (isDefaultStyle()) {
            return DateConversionUtil.getY4DateFormat(locale);
        }
        return getDateFormatForType();
    }

    protected DateFormat getDateFormat(String value, Locale locale) {
        String pattern = getPattern();
        if (pattern != null) {
            return new SimpleDateFormat(pattern, locale);
        }
        if (isDefaultStyle()) {
            return DateConversionUtil.getDateFormat(value, locale);
        }
        return getDateFormatForType();
    }

    protected boolean isDefaultStyle() {
        return STYLE_DEFAULT.equalsIgnoreCase(getDateStyle())
                && STYLE_DEFAULT.equalsIgnoreCase(getTimeStyle());
    }

    protected DateFormat getDateFormatForType() {
        String type = getType();
        if (type.equals(TYPE_DATE)) {
            return DateFormat.getDateInstance(calcStyle(getDateStyle()),
                    getLocale());
        } else if (type.equals(TYPE_TIME)) {
            return DateFormat.getTimeInstance(calcStyle(getTimeStyle()),
                    getLocale());
        } else if (type.equals(TYPE_BOTH)) {
            return DateFormat.getDateTimeInstance(calcStyle(getDateStyle()),
                    calcStyle(getTimeStyle()), getLocale());
        } else {
            return null;
        }
    }

    protected int calcStyle(String name) {
        if (name.equals(STYLE_DEFAULT)) {
            return DateFormat.DEFAULT;
        }
        if (name.equals(STYLE_MEDIUM)) {
            return DateFormat.MEDIUM;
        }
        if (name.equals(STYLE_SHORT)) {
            return DateFormat.SHORT;
        }
        if (name.equals(STYLE_LONG)) {
            return DateFormat.LONG;
        }
        if (name.equals(STYLE_FULL)) {
            return DateFormat.FULL;
        }
        return DateFormat.DEFAULT;
    }

}
