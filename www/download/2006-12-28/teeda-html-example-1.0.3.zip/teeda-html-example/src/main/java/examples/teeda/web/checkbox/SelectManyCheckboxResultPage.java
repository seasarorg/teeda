/**
 *
 */
package examples.teeda.web.checkbox;

import java.util.List;

/**
 * @author shot
 */
public class SelectManyCheckboxResultPage {

	private Integer aaa;

	private Integer bbb;
	
	private List aaaItems;

	public String initialize() {
		return null;
	}

	public Integer getAaa() {
		return aaa;
	}

	public void setAaa(Integer aaa) {
		this.aaa = aaa;
	}

	public List getAaaItems() {
		return aaaItems;
	}

	public void setAaaItems(List aaaItems) {
		this.aaaItems = aaaItems;
	}

	public Integer getBbb() {
		return bbb;
	}

	public void setBbb(Integer bbb) {
		this.bbb = bbb;
	}

}
