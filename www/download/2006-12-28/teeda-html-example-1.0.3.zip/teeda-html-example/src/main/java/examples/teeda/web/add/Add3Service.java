package examples.teeda.web.add;

public interface Add3Service {

	Add3Page doCalculate(Add3Page page);
}
