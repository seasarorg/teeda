package examples.teeda.web.newwindow;

public class TextOutputPage {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String initialize() {
		return null;
	}

	public String prerender() {
		return null;
	}

}
