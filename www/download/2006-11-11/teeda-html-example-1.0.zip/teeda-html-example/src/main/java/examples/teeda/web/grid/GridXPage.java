package examples.teeda.web.grid;

public class GridXPage extends GridPage {

}
