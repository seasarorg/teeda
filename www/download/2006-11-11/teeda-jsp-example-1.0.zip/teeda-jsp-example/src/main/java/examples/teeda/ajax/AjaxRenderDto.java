package examples.teeda.ajax;

import java.util.List;

public class AjaxRenderDto {

    private String date;

    private List dataList;

    public List getDataList() {
        return dataList;
    }

    public void setDataList(List dataList) {
        this.dataList = dataList;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
