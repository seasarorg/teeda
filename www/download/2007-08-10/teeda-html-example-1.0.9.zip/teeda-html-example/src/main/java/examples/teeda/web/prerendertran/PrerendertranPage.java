package examples.teeda.web.prerendertran;

public class PrerendertranPage {

	public Class initialize() {
		return null;
	}

	public Class prerender() {
		return Prerendertran2Page.class;
	}

}
