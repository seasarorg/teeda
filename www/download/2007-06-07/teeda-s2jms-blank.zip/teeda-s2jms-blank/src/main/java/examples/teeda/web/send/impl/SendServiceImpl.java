package examples.teeda.web.send.impl;

import org.seasar.jms.core.MessageSender;

import examples.teeda.web.send.SendService;

public class SendServiceImpl implements SendService {

	protected MessageSender sender;

	public SendServiceImpl() {
	}

	public void send(String message) {
		System.out.println("before : " + message);
		sender.send(message);
		System.out.println("after : " + message);
	}

	public void setSender(MessageSender sender) {
		this.sender = sender;
	}
}
