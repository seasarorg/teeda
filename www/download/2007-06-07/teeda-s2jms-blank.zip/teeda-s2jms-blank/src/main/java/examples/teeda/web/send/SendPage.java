package examples.teeda.web.send;

public class SendPage {

	protected String message;

	protected SendService service;

	public SendPage() {
	}

	public void doSend() {
		System.out.println(message);
		service.send(message);
		message = null;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setService(SendService service) {
		this.service = service;
	}
}
