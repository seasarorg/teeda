package examples.teeda.web.send;


public interface SendService {
    void send(String message);
}
