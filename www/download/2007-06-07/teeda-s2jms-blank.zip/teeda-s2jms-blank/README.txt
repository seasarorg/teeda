1.サンプル概要

　このサンプルはTeedaとS2JMSの簡単な通信のサンプルです。
TeedaとS2JMSを使うためのブランクプロジェクトとしてもお使いいただけます。
（本サンプルはTiger/Windows前提です。Mac/Linuxでもほぼ同様にお使いいただけるはずです）

2.インストール

2-1.ActiveMQのインストール

 ActiveMQ4.1.1をインストールしてください。misc/に同梱してあります。

2-2.S2JMS serverの設定

s2jms-activemq-blank-server_activemq-4.1.1.zipを解凍して、Eclipseプロジェクトとしてimportします。

2-3.起動

ActiveMQをインストールしたディレクトリに移動し、bin/activemq.batを起動します。
その後、s2jms-activemq-blank-server_activemq-4.1.1.zipを解凍したEclipseプロジェクトに
移動して、

java -jar lib\s2jms-server-1.0.0-M1.jar --classpath build\classes

とします。

その後、Webアプリケーションである「teeda-s2jms-blank」をTomcatで起動して、

http://localhost:8080/teeda-s2jms-blank/view/send/send.html

にアクセスしてみて、テキストを入力後サブミットしてみてください。
S2JMS Serverのコンソールの方にテキストが表示されていれば成功です。

Have fun!!!



