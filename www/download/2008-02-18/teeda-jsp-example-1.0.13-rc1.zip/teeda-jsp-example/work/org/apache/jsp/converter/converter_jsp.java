/*
 * Copyright 2004-2008 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.apache.jsp.converter;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class converter_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_f_view;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_h_form;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_h_messages_showDetail_globalOnly_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_h_inputText_value_id;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_f_convertDateTime_pattern_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_h_outputText_value;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_h_commandButton_id_nobody;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _jspx_tagPool_f_view = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_h_form = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_h_messages_showDetail_globalOnly_nobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_h_inputText_value_id = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_f_convertDateTime_pattern_nobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_h_outputText_value = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _jspx_tagPool_h_commandButton_id_nobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
  }

  public void _jspDestroy() {
    _jspx_tagPool_f_view.release();
    _jspx_tagPool_h_form.release();
    _jspx_tagPool_h_messages_showDetail_globalOnly_nobody.release();
    _jspx_tagPool_h_inputText_value_id.release();
    _jspx_tagPool_f_convertDateTime_pattern_nobody.release();
    _jspx_tagPool_h_outputText_value.release();
    _jspx_tagPool_h_commandButton_id_nobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("\t<title>converter</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      if (_jspx_meth_f_view_0(_jspx_page_context))
        return;
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_f_view_0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  f:view
    org.seasar.teeda.core.taglib.core.ViewTag _jspx_th_f_view_0 = (org.seasar.teeda.core.taglib.core.ViewTag) _jspx_tagPool_f_view.get(org.seasar.teeda.core.taglib.core.ViewTag.class);
    _jspx_th_f_view_0.setPageContext(_jspx_page_context);
    _jspx_th_f_view_0.setParent(null);
    int _jspx_eval_f_view_0 = _jspx_th_f_view_0.doStartTag();
    if (_jspx_eval_f_view_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_f_view_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_f_view_0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_f_view_0.doInitBody();
      }
      do {
        out.write('\r');
        out.write('\n');
        out.write('	');
        if (_jspx_meth_h_form_0(_jspx_th_f_view_0, _jspx_page_context))
          return true;
        out.write('\r');
        out.write('\n');
        int evalDoAfterBody = _jspx_th_f_view_0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_f_view_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_f_view_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_f_view.reuse(_jspx_th_f_view_0);
      return true;
    }
    _jspx_tagPool_f_view.reuse(_jspx_th_f_view_0);
    return false;
  }

  private boolean _jspx_meth_h_form_0(javax.servlet.jsp.tagext.JspTag _jspx_th_f_view_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  h:form
    org.seasar.teeda.core.taglib.html.FormTag _jspx_th_h_form_0 = (org.seasar.teeda.core.taglib.html.FormTag) _jspx_tagPool_h_form.get(org.seasar.teeda.core.taglib.html.FormTag.class);
    _jspx_th_h_form_0.setPageContext(_jspx_page_context);
    _jspx_th_h_form_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_f_view_0);
    int _jspx_eval_h_form_0 = _jspx_th_h_form_0.doStartTag();
    if (_jspx_eval_h_form_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      out.write("\r\n");
      out.write("\t\t");
      if (_jspx_meth_h_messages_0(_jspx_th_h_form_0, _jspx_page_context))
        return true;
      out.write("\r\n");
      out.write("\t\t");
      if (_jspx_meth_h_inputText_0(_jspx_th_h_form_0, _jspx_page_context))
        return true;
      out.write("\r\n");
      out.write("\t\t");
      if (_jspx_meth_h_outputText_0(_jspx_th_h_form_0, _jspx_page_context))
        return true;
      out.write("\r\n");
      out.write("\t\t");
      if (_jspx_meth_h_commandButton_0(_jspx_th_h_form_0, _jspx_page_context))
        return true;
      out.write('\r');
      out.write('\n');
      out.write('	');
    }
    if (_jspx_th_h_form_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_h_form.reuse(_jspx_th_h_form_0);
      return true;
    }
    _jspx_tagPool_h_form.reuse(_jspx_th_h_form_0);
    return false;
  }

  private boolean _jspx_meth_h_messages_0(javax.servlet.jsp.tagext.JspTag _jspx_th_h_form_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  h:messages
    org.seasar.teeda.core.taglib.html.MessagesTag _jspx_th_h_messages_0 = (org.seasar.teeda.core.taglib.html.MessagesTag) _jspx_tagPool_h_messages_showDetail_globalOnly_nobody.get(org.seasar.teeda.core.taglib.html.MessagesTag.class);
    _jspx_th_h_messages_0.setPageContext(_jspx_page_context);
    _jspx_th_h_messages_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_h_form_0);
    _jspx_th_h_messages_0.setGlobalOnly("false");
    _jspx_th_h_messages_0.setShowDetail("true");
    int _jspx_eval_h_messages_0 = _jspx_th_h_messages_0.doStartTag();
    if (_jspx_th_h_messages_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_h_messages_showDetail_globalOnly_nobody.reuse(_jspx_th_h_messages_0);
      return true;
    }
    _jspx_tagPool_h_messages_showDetail_globalOnly_nobody.reuse(_jspx_th_h_messages_0);
    return false;
  }

  private boolean _jspx_meth_h_inputText_0(javax.servlet.jsp.tagext.JspTag _jspx_th_h_form_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  h:inputText
    org.seasar.teeda.core.taglib.html.InputTextTag _jspx_th_h_inputText_0 = (org.seasar.teeda.core.taglib.html.InputTextTag) _jspx_tagPool_h_inputText_value_id.get(org.seasar.teeda.core.taglib.html.InputTextTag.class);
    _jspx_th_h_inputText_0.setPageContext(_jspx_page_context);
    _jspx_th_h_inputText_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_h_form_0);
    _jspx_th_h_inputText_0.setId("text1");
    _jspx_th_h_inputText_0.setValue("#{converterBean.date1}");
    int _jspx_eval_h_inputText_0 = _jspx_th_h_inputText_0.doStartTag();
    if (_jspx_eval_h_inputText_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      out.write("\r\n");
      out.write("\t\t\t");
      if (_jspx_meth_f_convertDateTime_0(_jspx_th_h_inputText_0, _jspx_page_context))
        return true;
      out.write("\r\n");
      out.write("\t\t");
    }
    if (_jspx_th_h_inputText_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_h_inputText_value_id.reuse(_jspx_th_h_inputText_0);
      return true;
    }
    _jspx_tagPool_h_inputText_value_id.reuse(_jspx_th_h_inputText_0);
    return false;
  }

  private boolean _jspx_meth_f_convertDateTime_0(javax.servlet.jsp.tagext.JspTag _jspx_th_h_inputText_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  f:convertDateTime
    org.seasar.teeda.core.taglib.core.ConvertDateTimeTag _jspx_th_f_convertDateTime_0 = (org.seasar.teeda.core.taglib.core.ConvertDateTimeTag) _jspx_tagPool_f_convertDateTime_pattern_nobody.get(org.seasar.teeda.core.taglib.core.ConvertDateTimeTag.class);
    _jspx_th_f_convertDateTime_0.setPageContext(_jspx_page_context);
    _jspx_th_f_convertDateTime_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_h_inputText_0);
    _jspx_th_f_convertDateTime_0.setPattern("yyyyMMdd");
    int _jspx_eval_f_convertDateTime_0 = _jspx_th_f_convertDateTime_0.doStartTag();
    if (_jspx_th_f_convertDateTime_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_f_convertDateTime_pattern_nobody.reuse(_jspx_th_f_convertDateTime_0);
      return true;
    }
    _jspx_tagPool_f_convertDateTime_pattern_nobody.reuse(_jspx_th_f_convertDateTime_0);
    return false;
  }

  private boolean _jspx_meth_h_outputText_0(javax.servlet.jsp.tagext.JspTag _jspx_th_h_form_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  h:outputText
    org.seasar.teeda.core.taglib.html.OutputTextTag _jspx_th_h_outputText_0 = (org.seasar.teeda.core.taglib.html.OutputTextTag) _jspx_tagPool_h_outputText_value.get(org.seasar.teeda.core.taglib.html.OutputTextTag.class);
    _jspx_th_h_outputText_0.setPageContext(_jspx_page_context);
    _jspx_th_h_outputText_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_h_form_0);
    _jspx_th_h_outputText_0.setValue("#{converterBean.date1}");
    int _jspx_eval_h_outputText_0 = _jspx_th_h_outputText_0.doStartTag();
    if (_jspx_eval_h_outputText_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      out.write("\r\n");
      out.write("\t\t\t");
      if (_jspx_meth_f_convertDateTime_1(_jspx_th_h_outputText_0, _jspx_page_context))
        return true;
      out.write("\r\n");
      out.write("\t\t");
    }
    if (_jspx_th_h_outputText_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_h_outputText_value.reuse(_jspx_th_h_outputText_0);
      return true;
    }
    _jspx_tagPool_h_outputText_value.reuse(_jspx_th_h_outputText_0);
    return false;
  }

  private boolean _jspx_meth_f_convertDateTime_1(javax.servlet.jsp.tagext.JspTag _jspx_th_h_outputText_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  f:convertDateTime
    org.seasar.teeda.core.taglib.core.ConvertDateTimeTag _jspx_th_f_convertDateTime_1 = (org.seasar.teeda.core.taglib.core.ConvertDateTimeTag) _jspx_tagPool_f_convertDateTime_pattern_nobody.get(org.seasar.teeda.core.taglib.core.ConvertDateTimeTag.class);
    _jspx_th_f_convertDateTime_1.setPageContext(_jspx_page_context);
    _jspx_th_f_convertDateTime_1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_h_outputText_0);
    _jspx_th_f_convertDateTime_1.setPattern("yyyy/MM/dd");
    int _jspx_eval_f_convertDateTime_1 = _jspx_th_f_convertDateTime_1.doStartTag();
    if (_jspx_th_f_convertDateTime_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_f_convertDateTime_pattern_nobody.reuse(_jspx_th_f_convertDateTime_1);
      return true;
    }
    _jspx_tagPool_f_convertDateTime_pattern_nobody.reuse(_jspx_th_f_convertDateTime_1);
    return false;
  }

  private boolean _jspx_meth_h_commandButton_0(javax.servlet.jsp.tagext.JspTag _jspx_th_h_form_0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  h:commandButton
    org.seasar.teeda.core.taglib.html.CommandButtonTag _jspx_th_h_commandButton_0 = (org.seasar.teeda.core.taglib.html.CommandButtonTag) _jspx_tagPool_h_commandButton_id_nobody.get(org.seasar.teeda.core.taglib.html.CommandButtonTag.class);
    _jspx_th_h_commandButton_0.setPageContext(_jspx_page_context);
    _jspx_th_h_commandButton_0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_h_form_0);
    _jspx_th_h_commandButton_0.setId("button1");
    int _jspx_eval_h_commandButton_0 = _jspx_th_h_commandButton_0.doStartTag();
    if (_jspx_th_h_commandButton_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _jspx_tagPool_h_commandButton_id_nobody.reuse(_jspx_th_h_commandButton_0);
      return true;
    }
    _jspx_tagPool_h_commandButton_id_nobody.reuse(_jspx_th_h_commandButton_0);
    return false;
  }
}
