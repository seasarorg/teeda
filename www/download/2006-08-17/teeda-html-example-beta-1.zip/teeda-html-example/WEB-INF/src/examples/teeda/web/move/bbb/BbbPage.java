/**
 *
 */
package examples.teeda.web.move.bbb;

/**
 * @author shot
 */
public class BbbPage {

}
