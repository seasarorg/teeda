package examples.teeda.web.prerendertran;

public class Prerendertran2Page {

	public String initialize() {
		return null;
	}

	public String prerender() {
		return null;
	}

}
