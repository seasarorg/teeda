package examples.teeda.web.grid;

public class GridResultPage {

	private String fff;

	public String getFff() {
		return fff;
	}

	public void setFff(String fff) {
		this.fff = fff;
	}

}
