package examples.teeda.web.hello;

public class HelloPage {

	private String name = "Seasar2";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}