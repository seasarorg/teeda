package examples.teeda.dto;

public class Aaa2Dto {

	private String bbb;

	public Aaa2Dto() {
		System.out.println("aaa");
	}

	public String getBbb() {
		return bbb;
	}

	public void setBbb(String bbb) {
		this.bbb = bbb;
	}

}
