package examples.teeda.web.prefix;

public class PrefixPage {

	public String initialize() {
		return null;
	}

	public String prerender() {
		return null;
	}

	public String doAction() {
		return "prefix2";
	}
}
