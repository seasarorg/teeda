package examples.teeda.web.layout;

public class HeaderPage {

	public Class initialize() {
		System.out.println("header init");
		return null;
	}

	public Class prerender() {
		System.out.println("header prerender");
		return null;
	}

}
