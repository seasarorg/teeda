package examples.teeda.web.grid;

public class GridResultPage {

	private String fff;

	private String ggg;

	public String getGgg() {
		return ggg;
	}

	public void setGgg(String ggg) {
		this.ggg = ggg;
	}

	public String getFff() {
		return fff;
	}

	public void setFff(String fff) {
		this.fff = fff;
	}

}
