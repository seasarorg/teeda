/**
 * 
 */
package examples.teeda.web.error;

/**
 * @author shot
 */
public class WebAppRuntimeException extends RuntimeException {

}
