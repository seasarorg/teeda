/**
 *
 */
package examples.teeda.web.select;

import java.util.List;

/**
 * @author shot
 */
public class SelectOneResultPage {

	private Integer aaa;

	private List aaaItems;

	public String initialize() {
		return null;
	}

	public Integer getAaa() {
		return aaa;
	}

	public void setAaa(Integer aaa) {
		this.aaa = aaa;
	}

	public List getAaaItems() {
		return aaaItems;
	}

	public void setAaaItems(List aaaItems) {
		this.aaaItems = aaaItems;
	}

}
