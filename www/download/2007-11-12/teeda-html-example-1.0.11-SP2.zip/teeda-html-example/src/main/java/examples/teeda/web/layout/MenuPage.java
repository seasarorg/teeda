package examples.teeda.web.layout;

public class MenuPage {

	public Class initialize() {
		System.out.println("menu init");
		return null;
	}

	public Class prerender() {
		System.out.println("menu prerender");
		return null;
	}

}
