package z4.web.emp;

import z4.entity.Emp;

public interface EmpDxo {

	public Emp convert(AbstractEmpPage src);
	
	public void convert(Emp src, AbstractEmpPage dest);
}