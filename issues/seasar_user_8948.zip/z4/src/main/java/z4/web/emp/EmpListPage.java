package z4.web.emp;

import java.math.BigDecimal;
import java.util.Date;

import org.seasar.teeda.extension.annotation.convert.DateTimeConverter;
import org.seasar.teeda.extension.annotation.takeover.TakeOver;

import z4.entity.Emp;
import z4.web.CrudType;

public class EmpListPage extends AbstractEmpPage {
	
	private Emp[] empItems;
	
	private int empIndex;
	
	public EmpListPage() {
	}
	
	public Class initialize() {
		return null;
	}
	
	public Class prerender() {
		empItems = getEmpDao().selectAll();
		return null;
	}
	
	public String getEmpRowClass() {
		if (getEmpIndex() % 2 == 0) {
			return "row_even";
		}
		return "row_odd";
	}

	@TakeOver(properties = "crudType")
	public Class doCreate() {
		setCrudType(CrudType.CREATE);
		return EmpEditPage.class;
	}
	
	@Override
	@DateTimeConverter
	public Date getHiredate() {
		return super.getHiredate();
	}

	public Emp[] getEmpItems() {
		return this.empItems;
	}

	public void setEmpItems(Emp[] items) {
		this.empItems = items;
	}
	
	public int getEmpIndex() {
		return this.empIndex;
	}
	
	public void setEmpIndex(int empIndex) {
		this.empIndex = empIndex;
	}
}