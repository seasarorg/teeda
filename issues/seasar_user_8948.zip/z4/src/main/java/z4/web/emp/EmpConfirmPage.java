package z4.web.emp;

import java.util.Date;

import org.seasar.teeda.core.exception.AppFacesException;
import org.seasar.teeda.extension.annotation.convert.DateTimeConverter;
import org.seasar.teeda.extension.annotation.takeover.TakeOver;
import org.seasar.teeda.extension.annotation.takeover.TakeOverType;
import org.seasar.teeda.extension.annotation.validator.Required;
import org.seasar.teeda.extension.util.LabelHelper;

import z4.dao.EmpDao;
import z4.entity.Emp;
import z4.web.CrudType;

public class EmpConfirmPage extends AbstractEmpPage {

	public static final String id_empDaoValidator = null;

	private LabelHelper labelHelper;

	public EmpConfirmPage() {
	}

	public String initialize() {
		if (isComeFromList()) {
			Emp data = getEmpDao().selectById(getId());
			if (data == null) {
				throw new AppFacesException("E0000001");
			}
			getEmpDxo().convert(data, this);
		}
		return null;
	}

	public String prerender() {
		return null;
	}

	@TakeOver(type = TakeOverType.NEVER)
	public String doFinish() {
		final EmpDao empDao = getEmpDao();
		switch (getCrudType()) {
		case CrudType.CREATE:
			empDao.insert(getEmpDxo().convert(this));
			break;
		case CrudType.UPDATE:
			Emp emp1 = getEmpDxo().convert(this);
			empDao.update(emp1);
			break;
		case CrudType.DELETE:
			empDao.delete(getEmpDxo().convert(this));
			break;
		default:
			break;
		}
		return "empList";
	}

	public boolean isComeFromList() {
		return getCrudType() == CrudType.READ
				|| getCrudType() == CrudType.DELETE;
	}

	@Override
	@Required
	public void setId(Integer id) {
		super.setId(id);
	}

	@Override
	@Required
	public void setEmpNo(Integer empno) {
		super.setEmpNo(empno);
	}

	@Override
	@DateTimeConverter
	public Date getHiredate() {
		return super.getHiredate();
	}

	public void setLabelHelper(LabelHelper labelHelper) {
		this.labelHelper = labelHelper;
	}

	public LabelHelper getLabelHelper() {
		return this.labelHelper;
	}

	public String getJumpEmpEditStyle() {
		return isComeFromList() ? "display: none;" : "";
	}

	public String getDoFinishValue() {
		return getLabelHelper().getLabelValue(CrudType.toString(getCrudType()));
	}
}