package z4.web.emp;

import java.math.BigDecimal;
import java.util.Date;

import org.seasar.teeda.extension.annotation.validator.Required;

import org.seasar.teeda.core.exception.AppFacesException;

import z4.entity.Emp;
import z4.web.CrudType;

public class EmpEditPage extends AbstractEmpPage {

	public EmpEditPage() {
	}
	
	public Class initialize() {
		if(getCrudType() == CrudType.UPDATE) {
			Emp data = getEmpDao().selectById(getId());
			if(data == null) {
				throw new AppFacesException("E0000001");
			}
			getEmpDxo().convert(data ,this);
		}
		return null;
	}
	
	public Class prerender() {
		return null;
	}

	@Override
	@Required
	public void setId(Integer id) {
		super.setId(id);
	}

	@Override
	@Required
	public void setEmpNo(Integer empno) {
		super.setEmpNo(empno);
	}

	public String getIsNotCreateStyle() {
		return getCrudType() == CrudType.CREATE ? "display: none;" : null;
	}
}