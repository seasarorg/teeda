var fdTableSort = {

    init: function() {
      
        if (!document.getElementsByTagName) {
            return;
        }

        var headers = document.getElementsByTagName("th");
        var th;
        for (var i = 0; th = headers[i]; i++) {
            if (th.className.match("sorttable")) {
                th.onclick = fdTableSort.initSort;

                // th/div/nobr
                var sortTag = th.getElementsByTagName("nobr")[0];

                var sortText = sortTag.innerHTML;
                sortTag.innerHTML = "";

                // Insert ancher to text.
                var anchor = sortTag.appendChild(document.createElement("a"));
                anchor.href = "#";
                anchor.appendChild(document.createTextNode(sortText));

                // Insert span for sort.
                var span = sortTag.appendChild(document.createElement("span"));
                span.id      = "sortableSpan";
                span.onclick = "return false";
            }
        }
    },

    initSort: function(e) {

        var curr = this;
        var pos = 0;

        while (curr.previousSibling) {
            if (curr.previousSibling.nodeType != 3) {
                pos++;
            }
            curr = curr.previousSibling;
        }

        // Remove "reverse" class
        var thCollection = curr.parentNode.getElementsByTagName("th");
        var th;
        for (var i = 0; th = thCollection[i]; i++) {
            if (i != pos) {
                th.className = th.className.replace("reverseSort","");
                var span = th.getElementsByTagName("span");
                if (span.length > 0) {
                    var span = th.getElementsByTagName("span")[span.length - 1];
                    if (span.firstChild && span.id == "sortableSpan") {
                        span.removeChild(span.firstChild);
                    }
                    span.appendChild(document.createTextNode(""));
                }
            }
        }

        // Get table
        var tableElem = this;
        while(tableElem.tagName.toLowerCase() != "table" && tableElem.parentNode) {
            tableElem = tableElem.parentNode;
        }

        // Get tr
        var trElem = tableElem.getElementsByTagName("tr");
        var trCollection = new Array();
        var tr;
        for (var i = 0; tr = trElem[i]; i++) {
            if (tr.getElementsByTagName("th").length == 0) {
                trCollection.push(tr);
            }
        }

        // Do we need to reverse the sort?
        var arrow;
        var order;
        if (this.className.match("reverseSort")) {
            this.className = this.className.replace("reverseSort","");
            arrow = " \u25b3";
            order = "asc";
            
        } else {
            this.className = this.className + " reverseSort";
            arrow = " \u25bd";
            order = "desc";
        }

        var span = this.getElementsByTagName("span");
        if (span.length > 0) {
            var span = this.getElementsByTagName("span")[span.length - 1];
            if (span.firstChild && span.id == "sortableSpan") {
                span.removeChild(span.firstChild);
            }
            span.appendChild(document.createTextNode(arrow));
        }
		
        var sortId;
		var sortOrder = order;
		
		var splitIndex = this.id.indexOf("-");
		if (splitIndex > 0) {
			sortId = this.id.substring(0, splitIndex);
		} else {
			sortId = this.id;
		}

alert("id=" + sortId + ", order=" + sortOrder);
    }

}

addEvent(window, "load", fdTableSort.init);


