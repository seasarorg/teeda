function doLinkAction(aElem, buttonId) {
    var form        = document.forms[0];
    var hrefValue   = aElem.href.replace("#", "");
	var queryString = hrefValue.substring(aElem.href.indexOf("?") + 1, aElem.href.length);
    var querys      = queryString.split("&");

	// create input form
	var query;
	for (var i = 0; query = querys[i]; i++) {
		var splitIndex = query.indexOf("=");
		var elemId;
		var elemValue;
		if (splitIndex > 0) {
			elemId    = query.substring(0,              splitIndex);
			elemValue = query.substring(splitIndex + 1, query.length);

			var elem = document.getElementById(elemId + "Select");
			if(elem != null) {
				elem.value = elemValue;
			}
		}
	}

	aElem.href = "#";

	var submitButton = document.getElementById(buttonId);
	if(submitButton != null) {
		submitButton.click();
	} else {
		return false;
	}
}

//-----------------------------------------------------------------------------
// Teedaのグリッドのセルを変更したことを保持する。 
//
// cell : セル（divタグであることを想定）
function gridCellOnChange(cell) {
    var EDIT_ADD    = 1;
    var EDIT_UPDATE = 2;
    
    // find tr tag
    var node = cell.parentNode;
    while (node != null || node != "undefined") {
        var currentTagName = node.tagName;
        if(currentTagName == "TR") {
            break;
        }
        node = node.parentNode;
    }
    
    if (node == null || node == "undefined") {
        return;
    }
    
    // change editStatus to update
    // if editStatus is add, not change
    var inputNodeArray = node.getElementsByTagName("input");
    var inputNode;
    for (var i = 0; inputNode = inputNodeArray[i]; i++) {
        if(inputNode.id == "editStatus") {
            var status = inputNode.value;
            if (status != EDIT_ADD) {
                inputNode.value = EDIT_UPDATE;
            }
        }
    }
}
