function scroll(layerId) {
    var rightHeaderId = layerId.replace("Body", "Header");
    var rightBodyId   = layerId;
    var leftBodyId    = layerId.replace("Right", "Left");
    
    var rightHeaderLayer = document.getElementById(rightHeaderId);
    var rightBodyLayer   = document.getElementById(rightBodyId);
    var leftBodyLayer    = document.getElementById(leftBodyId);
    
    rightHeaderLayer.scrollLeft = rightBodyLayer.scrollLeft;
    leftBodyLayer.scrollTop     = rightHeaderLayer.scrollTop;
}

var cssChange = {
    
    focus: function(e) {
        e.className = e.className.replace("Blur", "Focus");
    },
    
    blur: function(e) {
        e.className = e.className.replace("Focus", "Blur");
    }
}

var fdGrid = {
    
    initForeachGrid: function() {
        
        if (!document.getElementsByTagName) {
            return;
        }
        
        var grids = getElementsByClassName("eGridTable");
        var grid; 
        for (var i = 0; grid = grids[i]; i++) {
            var inputElems = grid.getElementsByTagName("input");
            var inputElem;
            for (var j = 0; inputElem = inputElems[j]; j++) {
                if(inputElem.type == "text") {         
                    inputElem.onchange = fdGrid.onChange;
                }
            }
        }
    },
    
    onChange: function(e) {
        var EDIT_ADD    = 1;
        var EDIT_UPDATE = 2;
    
        // change editStatus to update
        // if editStatus is add, not change
        var inputNodeArray = findNodesInParent(this, "td", "input");
        var inputNode;
        for (var i = 0; inputNode = inputNodeArray[i]; i++) {
            if(inputNode.id == this.id + "EditStatus") {
                var status = inputNode.value;
                if (status != EDIT_ADD) {
                    inputNode.value = EDIT_UPDATE;
                }
            }
        }
    }
    
}

function findNodesInParent(childNode, parentTagName, targetTagName) {
    
    parentTagName = parentTagName.toUpperCase();
    targetTagName = targetTagName.toUpperCase();
    
        var nodeArray;
        var node = childNode.parentNode;
        while (node != null || node != "undefined") {
            var currentTagName = node.tagName;
            if(currentTagName == parentTagName) {
                break;
            }
            node = node.parentNode;
        }
        
        if (node == null || node == "undefined") {
            return nodeArray;
        }
        
        var nodeArray = node.getElementsByTagName(targetTagName);
        
        return nodeArray;
}

addEvent(window, "load", fdGrid.initForeachGrid);
