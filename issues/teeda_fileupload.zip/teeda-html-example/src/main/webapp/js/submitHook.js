var fdSubmitHook = {

    hookMessageId:    "hookMessage",
    hookMessageText:  "条件が変更されています。",
    hookMessageClass: "error",
    isChanged:        false,

    notify: function(e) {
        fdSubmitHook.isChanged = true;
    },

    hook: function(e) {
        window.event.returnValue = (!fdSubmitHook.isChanged);
        
        var messageElem = document.getElementById(fdSubmitHook.hookMessageId);
        if(messageElem == null || messageElem == "undefined") {
            fdSubmitHook.viewMessage();
        }
    },
    
    viewMessage: function() {
        var ulTag = document.createElement("ul");
        var liTag = document.createElement("li");
        ulTag.appendChild(liTag);
        
        liTag.id        = fdSubmitHook.hookMessageId;
        liTag.innerHTML = fdSubmitHook.hookMessageText;
        liTag.className = fdSubmitHook.hookMessageClass;
        
        // insert message into form tag.
        document.forms[0].insertBefore(ulTag, document.forms[0].firstChild);
    }

}
