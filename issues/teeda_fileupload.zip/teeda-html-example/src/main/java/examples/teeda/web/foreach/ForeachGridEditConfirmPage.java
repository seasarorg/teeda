package examples.teeda.web.foreach;

public class ForeachGridEditConfirmPage extends AbstractForeachGridPage {
    
    public ForeachGridEditConfirmPage() {}
    
    public String doSubmit() {
        return null;
    }

}
