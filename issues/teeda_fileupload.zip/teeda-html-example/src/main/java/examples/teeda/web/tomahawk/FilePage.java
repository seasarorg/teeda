/**
 *
 */
package examples.teeda.web.tomahawk;

import java.io.Serializable;

import org.apache.myfaces.custom.fileupload.UploadedFile;

/**
 * @author shot
 */
public class FilePage implements Serializable {

	private static final long serialVersionUID = 1L;

	private UploadedFile uploadedFile;

	public UploadedFile getUploadedFile() {
		return this.uploadedFile;
	}

	public void setUploadedFile(UploadedFile uploadedFile) {
		this.uploadedFile = uploadedFile;
		System.out.println("#####uploadFileSize[" + uploadedFile.getSize()
				+ "]");
	}

	public String doUpload() {
		if (uploadedFile != null) {
			System.out.println("#####uploadFileSize[" + uploadedFile.getSize()
					+ "]");
		}
		return null;
	}

}
