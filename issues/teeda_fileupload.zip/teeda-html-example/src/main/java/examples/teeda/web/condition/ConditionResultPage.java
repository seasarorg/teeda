/**
 *
 */
package examples.teeda.web.condition;

/**
 * @author shot
 */
public class ConditionResultPage {

	private Boolean bbb = null;

	public Boolean isBbb() {
		return bbb;
	}

	public void setBbb(Boolean bbb) {
		this.bbb = bbb;
	}

}
