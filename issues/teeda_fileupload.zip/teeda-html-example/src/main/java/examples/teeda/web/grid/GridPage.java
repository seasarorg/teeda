package examples.teeda.web.grid;

import java.math.BigDecimal;

public class GridPage {

	private FooItem[] fooItems;

	private int fooIndex;

	public String getFooRowStyleClass() {
		if (fooIndex % 2 == 0) {
			return "row_even";
		}
		return "row_odd";
	}

	private static final int NUM = 2000;

	public FooItem[] getFooItems() {
		if (fooItems == null) {
			// fooItems = new FooItem[5000];
			fooItems = new FooItem[NUM];
			for (int i = 0; i < NUM; i++) {
				fooItems[i] = createItem("a" + (i + 1), "b" + (i + 1), "c"
						+ (i + 1), "d" + (i + 1), new BigDecimal(i + 1), "f"
						+ (i + 1), "g" + (i + 1));
			}
		} else {
			FooItem[] newItems = new FooItem[NUM];
			for (int i = 0; i < NUM; i++) {
				newItems[i] = createItem("a" + (i + 1), "b" + (i + 1), "c"
						+ (i + 1), fooItems[i].getD(), fooItems[i].getE(), "f"
						+ (i + 1), "g" + (i + 1));
			}
			fooItems = newItems;
		}
		return fooItems;
	}

	private FooItem createItem(String a, String b, String c, String d,
			BigDecimal e, String f, String g) {
		final FooItem item = new FooItem();
		item.setA(a);
		item.setB(b);
		item.setC(c);
		item.setD(d);
		item.setE(e);
		item.setF(f);
		item.setG(g);
		return item;
	}

	public void setFooItems(FooItem[] fooItems) {
		this.fooItems = fooItems;
	}

	public static class FooItem {

		private String a;

		private String b;

		private String c;

		private String d;

		private BigDecimal e;

		private String f;

		private String g;

		public String getG() {
			return g;
		}

		public void setG(String g) {
			this.g = g;
		}

		public String getA() {
			return a;
		}

		public void setA(String a) {
			this.a = a;
		}

		public String getB() {
			return b;
		}

		public void setB(String b) {
			this.b = b;
		}

		public String getC() {
			return c;
		}

		public void setC(String c) {
			this.c = c;
		}

		public String getD() {
			return d;
		}

		public void setD(String d) {
			this.d = d;
		}

		public BigDecimal getE() {
			return e;
		}

		public void setE(BigDecimal e) {
			this.e = e;
		}

		public String getF() {
			return f;
		}

		public void setF(String f) {
			this.f = f;
		}

	}

	private String a;

	private String b;

	private String c;

	private String d;

	private BigDecimal e;

	private String f;

	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public String getB() {
		return b;
	}

	public void setB(String b) {
		this.b = b;
	}

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getD() {
		return d;
	}

	public void setD(String d) {
		this.d = d;
	}

	public BigDecimal getE() {
		return e;
	}

	public void setE(BigDecimal e) {
		this.e = e;
	}

	public String getF() {
		return f;
	}

	public void setF(String f) {
		this.f = f;
	}

	public void setFooIndex(int fooIndex) {
		this.fooIndex = fooIndex;
	}

}
