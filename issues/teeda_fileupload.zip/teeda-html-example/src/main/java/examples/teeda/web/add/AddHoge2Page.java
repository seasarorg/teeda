/**
 *
 */
package examples.teeda.web.add;

/**
 * @author shot
 * 
 */
public class AddHoge2Page {

	private String a;

	private String b;

	public String initilize() {
		return null;
	}

	public String prerender() {
		return null;
	}

	public String getA() {
		return a;
	}

	public String getB() {
		return b;
	}

	public void setA(String a) {
		this.a = a;
	}

	public void setB(String b) {
		this.b = b;
	}

}
