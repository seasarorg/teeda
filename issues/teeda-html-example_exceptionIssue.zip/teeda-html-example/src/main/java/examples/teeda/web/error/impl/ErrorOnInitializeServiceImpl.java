/**
 *
 */
package examples.teeda.web.error.impl;

import examples.teeda.web.error.ErrorOnInitializeService;

/**
 * @author shot
 * 
 */
public class ErrorOnInitializeServiceImpl implements ErrorOnInitializeService {

	public void execute() {
		System.out.println("EEEEEE");
		// throw new WebAppRuntimeException("ErrorPage throws exception.");
	}

}
