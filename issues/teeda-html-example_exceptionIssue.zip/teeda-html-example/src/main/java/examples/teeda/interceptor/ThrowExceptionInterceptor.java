/**
 *
 */
package examples.teeda.interceptor;

import org.aopalliance.intercept.MethodInvocation;
import org.seasar.framework.aop.interceptors.TraceInterceptor;

import examples.teeda.web.error.WebAppRuntimeException;

/**
 * @author shot
 * 
 */
public class ThrowExceptionInterceptor extends TraceInterceptor {

	public Object invoke(MethodInvocation arg0) throws Throwable {
		throw new WebAppRuntimeException("Throw ex at interceptor");
	}

}
