/**
 *
 */
package examples.teeda.web.error;

/**
 * @author shot
 * 
 */
public interface ErrorOnInitializeService {

	void execute();
}
