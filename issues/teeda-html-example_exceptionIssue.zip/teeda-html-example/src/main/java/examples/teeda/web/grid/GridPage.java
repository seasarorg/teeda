/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package examples.teeda.web.grid;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class GridPage {

	private FooItem[] fooItems;

	private int fooIndex;

	public String getFooRowClass() {
		if (fooIndex % 2 == 0) {
			return "row_even";
		}
		return "row_odd";
	}

	public String getFooRowStyle() {
		if (fooIndex % 2 == 0) {
			return "color : red";
		}
		return "color : blue";
	}

	private Map[] fffItems;

	private String xxx;

	private String yyy;

	private Boolean zzz;

	public String initialize() {
		fooItems = new FooItem[7];
		fffItems = new HashMap[1];
		{
			Map map = new HashMap();
			map.put("xxx", "A");
			map.put("yyy", "B");
			map.put("zzz", Boolean.TRUE);
			fffItems[0] = map;
		}
		fooItems[0] = createItem("a1", "b1", "c1", "d1", new BigDecimal(
				"11111111"), fffItems, "g1");
		fooItems[1] = createItem("a2", "b2", "c2", "d2",
				new BigDecimal("2222"), fffItems, "g2");
		fooItems[2] = createItem("a3", "b3", "c3", "d3",
				new BigDecimal("33333"), fffItems, "g3");
		fooItems[3] = createItem("a4", "b4", "c4", "d4", new BigDecimal("44"),
				fffItems, "g4");
		fooItems[4] = createItem("a5", "b5", "c5", "d5", new BigDecimal("5"),
				fffItems, "g5");
		fooItems[5] = createItem("a6", "b6", "c6", "d6", new BigDecimal("-6"),
				fffItems, "g6");
		fooItems[6] = createItem("a7", "b7", "c7", "d7", new BigDecimal("0"),
				fffItems, "g7");
		return null;
	}

	public FooItem[] getFooItems() {
		return fooItems;
	}

	private FooItem createItem(String aaa, String bbb, String ccc, String ddd,
			BigDecimal eee, Map[] hogeItems, String ggg) {
		final FooItem item = new FooItem();
		item.setAaa(aaa);
		item.setBbb(bbb);
		item.setCcc(ccc);
		item.setDdd(ddd);
		item.setEee(eee);
		item.setFffItems(hogeItems);
		item.setGgg(ggg);
		return item;
	}

	public String doSubmit() {
		System.out.println("aaa");
		return null;
	}

	public void setFooItems(FooItem[] fooItems) {
		this.fooItems = fooItems;
	}

	public static class FooItem implements Serializable {

		private String aaa;

		private String bbb;

		private String ccc;

		private String ddd;

		private BigDecimal eee;

		private Map[] fff;

		private String ggg;

		public String getGgg() {
			return ggg;
		}

		public void setGgg(String ggg) {
			this.ggg = ggg;
		}

		public String getBbb() {
			return bbb;
		}

		public void setBbb(String bar) {
			this.bbb = bar;
		}

		public String getAaa() {
			return aaa;
		}

		public void setAaa(String foo) {
			this.aaa = foo;
		}

		public String getCcc() {
			return ccc;
		}

		public void setCcc(String ccc) {
			this.ccc = ccc;
		}

		public String getDdd() {
			return ddd;
		}

		public void setDdd(String ddd) {
			this.ddd = ddd;
		}

		public BigDecimal getEee() {
			return eee;
		}

		public void setEee(BigDecimal eee) {
			this.eee = eee;
		}

		public Map[] getFffItems() {
			return fff;
		}

		public void setFffItems(Map[] fff) {
			this.fff = fff;
		}
	}

	private String aaa;

	private String bbb;

	private String ccc;

	private String ddd;

	private BigDecimal eee;

	private String fff;

	private String ggg;

	public String getGgg() {
		return ggg;
	}

	public void setGgg(String ggg) {
		this.ggg = ggg;
	}

	public String getBbb() {
		return bbb;
	}

	public void setBbb(String bar) {
		this.bbb = bar;
	}

	public String getAaa() {
		return aaa;
	}

	public void setAaa(String foo) {
		this.aaa = foo;
	}

	public String getCcc() {
		return ccc;
	}

	public void setCcc(String ccc) {
		this.ccc = ccc;
	}

	public String getDdd() {
		return ddd;
	}

	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	public BigDecimal getEee() {
		return eee;
	}

	public void setEee(BigDecimal eee) {
		this.eee = eee;
	}

	public String getFff() {
		return fff;
	}

	public void setFff(String fff) {
		this.fff = fff;
	}

	public void setFooIndex(int fooIndex) {
		this.fooIndex = fooIndex;
	}

	public String getXxx() {
		return xxx;
	}

	public String getYyy() {
		return yyy;
	}

	public Boolean getZzz() {
		return zzz;
	}

	public void setXxx(String xxx) {
		this.xxx = xxx;
	}

	public void setYyy(String yyy) {
		this.yyy = yyy;
	}

	public void setZzz(Boolean zzz) {
		this.zzz = zzz;
	}

	public Map[] getHogeItems() {
		return fffItems;
	}

	public void setHogeItems(Map[] hogeItems) {
		this.fffItems = hogeItems;
	}

}
